from .pred_as1 import main
